# Native Camera - version 0.1 (first build)

A native Android camera app (Kotlin + Camera2). It talks to the camera hardware
directly, uses no web view and no external libraries, and adds no filters or
enhancement of its own. Works on Android 10 (API 29) and newer.

## IMPORTANT - read first
This code was written and checked by reading and by automatic syntax checks only.
It has NOT been compiled or run on a phone yet (the build environment had no
Android SDK). Expect to fix a few small errors on the first build. Paste any
error text back and they can be fixed quickly.

## How to build the APK
1. Install Android Studio (a recent version that supports Android Gradle Plugin 9.3).
2. File > Open > choose this folder (the one containing settings.gradle.kts).
3. Wait for "Gradle sync". Accept any offer to download SDK 36 / Gradle 9.5.
   If Studio suggests a newer plugin version, accept it.
4. Plug in a phone (USB debugging on) and press Run, or use
   Build > Build APK(s). The APK ends up in app/build/outputs/apk/debug/.
5. Photos and videos are saved to DCIM/NativeCamera.

## Option B - build the APK in the cloud (no Android Studio needed)
1. Make a free GitHub account and create a new repository.
2. Upload the contents of this folder to it (keep the .github folder).
3. Open the repository's "Actions" tab. The "Build APK" job starts by itself
   (or press "Run workflow"). It takes a few minutes.
4. When it shows a green tick, open the run and download "NativeCamera-debug-apk".
   Unzip it, copy the .apk to the phone and install it (allow "install unknown apps").
If the job fails (red cross), open it and copy the error text - that is what is
needed to fix the code.

## What works in this version
Hardware diagnostic system
- Scans every camera on launch: hardware level, capabilities, ISO / exposure
  ranges, focus, flash, zoom, photo / RAW / video sizes, frame rates.
- Checks the phone's hardware video encoders (H.264, HEVC) separately.
- "Scan" button: full report on screen, re-scan, and share as JSON.
- The screen offers only what the phone reports.

Photo
- JPEG, RAW (DNG), or JPEG+DNG where the phone supports RAW.
- Every size the camera reports (shown as real megapixels), including the
  full-resolution mode of binned sensors (for example 50 MP) on Android 12+.
- Aspect ratios the camera reports natively (4:3, 16:9, 1:1, 3:2 ...), front camera included.
- JPEG quality 100, no app-added processing. "Minimal processing" asks the camera
  for the least noise reduction / sharpening the phone allows (some phones ignore it).

Video
- Native recording (Camera2 -> hardware encoder -> MP4), with sound.
- H.264 or HEVC. Resolutions and frame rates (24 / 30 / 60, including 4K 60) are
  listed only when BOTH the camera and a hardware encoder report them.
- Pause / resume.

Controls
- Tap to focus, pinch zoom, exposure compensation, flash / torch, timer,
  grid, volume-button shutter, switch cameras, gallery shortcut.
- Pro panel: manual ISO, manual shutter, manual focus (only if the camera supports them).

## NOT in this version yet
- Test recordings that confirm a mode really works (modes are "reported", not "verified").
- 10-bit / HDR video (needs a different video pipeline).
- Cropped aspect ratios (shapes the camera does not report natively).
- Dual camera, slow motion, time-lapse, panorama, QR scanner, document scan,
  night mode, hands-free shutter, histogram, level.
- Photo while recording, selfie mirror option, screen flash, location tags option,
  HEIC, low-storage / low-battery warnings, lock-screen quick launch, landscape layout.
- Physical-lens selection behind a multi-lens camera (they are listed in the report).

## Known limits
- Phone makers still process JPEG and video in the camera chip. RAW is the
  closest thing to untouched sensor data.
- Full-resolution (50 MP) mode and RAW at full size are the least tested parts.
- Phones whose camera sensor is not rotated 90 degrees (some tablets) may show a
  sideways preview.
