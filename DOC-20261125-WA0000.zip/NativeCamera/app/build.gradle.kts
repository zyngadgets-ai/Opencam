plugins {
    id("com.android.application")
}

android {
    namespace = "com.nativecamera.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.nativecamera.app"
        minSdk = 29
        targetSdk = 36
        versionCode = 1
        versionName = "0.1.0"
    }

    lint {
        abortOnError = false
    }
}
// No external libraries on purpose: the app uses only the Android framework
// (Camera2, MediaRecorder, MediaStore), so there is nothing extra to download.
