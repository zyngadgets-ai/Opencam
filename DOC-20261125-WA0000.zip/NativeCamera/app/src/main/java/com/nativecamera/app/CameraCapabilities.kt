package com.nativecamera.app

import android.content.Context
import android.graphics.ImageFormat
import android.graphics.Rect
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.media.MediaCodecList
import android.media.MediaFormat
import android.media.MediaRecorder
import android.os.Build
import android.util.Range
import android.util.Size
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.math.abs

data class PhotoSize(val size: Size, val fullRes: Boolean) {
    val megapixels: Double get() = size.width.toDouble() * size.height / 1_000_000.0
    val label: String
        get() = String.format(Locale.US, "%.1f MP", megapixels) + if (fullRes) " full-res" else ""
}

data class VideoSize(val size: Size, val maxFps: Int)

data class VideoMode(val size: Size, val fps: Int) {
    val label: String get() = resolutionName(size.width, size.height) + " " + fps
}

data class CameraProfile(
    val id: String,
    val facing: String,
    val hardwareLevel: String,
    val physicalIds: List<String>,
    val focalLengths: List<Float>,
    val sensorOrientation: Int,
    val activeArray: Rect,
    val capabilities: List<String>,
    val manualSensor: Boolean,
    val manualFocus: Boolean,
    val rawSupported: Boolean,
    val tenBitAdvertised: Boolean,
    val flashAvailable: Boolean,
    val isoRange: Range<Int>?,
    val exposureRangeNs: Range<Long>?,
    val minFocusDiopters: Float,
    val zoomRange: Range<Float>?,
    val maxDigitalZoom: Float,
    val aeCompRange: Range<Int>,
    val aeCompStep: Float,
    val afModes: List<Int>,
    val maxAfRegions: Int,
    val maxAeRegions: Int,
    val fpsRanges: List<Range<Int>>,
    val noiseModes: List<Int>,
    val edgeModes: List<Int>,
    val stabilization: List<String>,
    val photoSizes: List<PhotoSize>,
    val rawSizes: List<PhotoSize>,
    val videoSizes: List<VideoSize>
) {
    val label: String
        get() = facing + " " + id +
            (if (focalLengths.isNotEmpty()) String.format(Locale.US, " (%.1fmm)", focalLengths[0]) else "")
}

fun resolutionName(w: Int, h: Int): String {
    val s = minOf(w, h)
    return when {
        s >= 4320 -> "8K"
        s >= 2160 -> "4K"
        else -> "${s}p"
    }
}

private val KNOWN_RATIOS = listOf(
    "1:1" to 1.0,
    "5:4" to 1.25,
    "4:3" to 4.0 / 3.0,
    "3:2" to 1.5,
    "16:10" to 1.6,
    "16:9" to 16.0 / 9.0,
    "2:1" to 2.0,
    "19.5:9" to 19.5 / 9.0,
    "20:9" to 20.0 / 9.0
)

/** Shape of a size, written long side : short side, e.g. 4:3 or 16:9. */
fun ratioLabel(w: Int, h: Int): String {
    val r = maxOf(w, h).toDouble() / minOf(w, h)
    val best = KNOWN_RATIOS.minByOrNull { abs(it.second - r) }
    if (best != null && abs(best.second - r) < 0.03) return best.first
    return String.format(Locale.US, "%.2f:1", r)
}

/** What the phone's hardware video encoders can do (checked independently of the camera). */
object Encoders {
    private fun encoders(mime: String) =
        MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.filter { info ->
            info.isEncoder && info.isHardwareAccelerated &&
                info.supportedTypes.any { it.equals(mime, ignoreCase = true) }
        }

    fun available(mime: String): Boolean = encoders(mime).isNotEmpty()

    fun supports(mime: String, w: Int, h: Int, fps: Int): Boolean = encoders(mime).any { info ->
        try {
            info.getCapabilitiesForType(mime).videoCapabilities
                ?.areSizeAndRateSupported(w, h, fps.toDouble()) == true
        } catch (e: Exception) {
            false
        }
    }
}

object Capabilities {
    @Volatile
    var profiles: List<CameraProfile> = emptyList()

    fun scan(context: Context) {
        val mgr = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val found = mgr.cameraIdList.mapNotNull { id ->
            try {
                scanOne(mgr, id)
            } catch (e: Exception) {
                null
            }
        }
        // Back cameras first, then front, then anything else (stable order inside each group).
        profiles = found.sortedBy {
            when (it.facing) {
                "Back" -> 0
                "Front" -> 1
                else -> 2
            }
        }
    }

    private fun capName(i: Int): String = when (i) {
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE -> "BACKWARD_COMPATIBLE"
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR -> "MANUAL_SENSOR"
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_POST_PROCESSING -> "MANUAL_POST_PROCESSING"
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_RAW -> "RAW"
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_READ_SENSOR_SETTINGS -> "READ_SENSOR_SETTINGS"
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_BURST_CAPTURE -> "BURST_CAPTURE"
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_CONSTRAINED_HIGH_SPEED_VIDEO -> "HIGH_SPEED_VIDEO"
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_LOGICAL_MULTI_CAMERA -> "LOGICAL_MULTI_CAMERA"
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_DEPTH_OUTPUT -> "DEPTH_OUTPUT"
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MONOCHROME -> "MONOCHROME"
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_ULTRA_HIGH_RESOLUTION_SENSOR -> "ULTRA_HIGH_RESOLUTION_SENSOR"
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_DYNAMIC_RANGE_TEN_BIT -> "DYNAMIC_RANGE_TEN_BIT"
        else -> "capability#$i"
    }

    private fun scanOne(mgr: CameraManager, id: String): CameraProfile? {
        val c = mgr.getCameraCharacteristics(id)
        val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP) ?: return null
        val capInts = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)?.toList() ?: emptyList()
        // Skip depth / infrared-only cameras that cannot take normal pictures.
        if (!capInts.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE)) return null
        val active = c.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE) ?: return null

        val facing = when (c.get(CameraCharacteristics.LENS_FACING)) {
            CameraMetadata.LENS_FACING_FRONT -> "Front"
            CameraMetadata.LENS_FACING_BACK -> "Back"
            else -> "External"
        }
        val level = when (c.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)) {
            CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_LEGACY -> "LEGACY"
            CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED -> "LIMITED"
            CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_FULL -> "FULL"
            CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_3 -> "LEVEL_3"
            CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_EXTERNAL -> "EXTERNAL"
            else -> "UNKNOWN"
        }

        val iso = c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
        val exp = c.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
        val minFocus = c.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f

        val jpeg = map.getOutputSizes(ImageFormat.JPEG)?.toList() ?: emptyList()
        val photo = ArrayList<PhotoSize>()
        jpeg.filter { it.width * it.height >= 1_000_000 }.forEach { photo.add(PhotoSize(it, false)) }
        val maxJpeg = jpeg.maxOfOrNull { it.width * it.height } ?: 0

        val raw = map.getOutputSizes(ImageFormat.RAW_SENSOR)?.toList() ?: emptyList()
        val rawList = ArrayList<PhotoSize>()
        raw.forEach { rawList.add(PhotoSize(it, false)) }
        val maxRaw = raw.maxOfOrNull { it.width * it.height } ?: 0

        // Sensors that bin pixels by default (for example 50 MP -> 12.5 MP) list the true
        // full-resolution sizes in a separate "maximum resolution" map (Android 12+).
        if (Build.VERSION.SDK_INT >= 31) {
            val big = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP_MAXIMUM_RESOLUTION)
            big?.getOutputSizes(ImageFormat.JPEG)?.forEach {
                if (it.width * it.height > maxJpeg) photo.add(PhotoSize(it, true))
            }
            big?.getOutputSizes(ImageFormat.RAW_SENSOR)?.forEach {
                if (it.width * it.height > maxRaw) rawList.add(PhotoSize(it, true))
            }
        }

        val video = (map.getOutputSizes(MediaRecorder::class.java)?.toList() ?: emptyList())
            .filter { it.width >= 640 }
            .map { s ->
                val dur = map.getOutputMinFrameDuration(MediaRecorder::class.java, s)
                VideoSize(s, if (dur > 0) (1_000_000_000L / dur).toInt() else 30)
            }

        val stab = ArrayList<String>()
        if (c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)
                ?.contains(CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON) == true
        ) stab.add("OIS")
        if (c.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)
                ?.contains(CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON) == true
        ) stab.add("EIS")

        val manualSensor = capInts.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR) &&
            iso != null && exp != null

        return CameraProfile(
            id = id,
            facing = facing,
            hardwareLevel = level,
            physicalIds = c.physicalCameraIds.toList(),
            focalLengths = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.toList() ?: emptyList(),
            sensorOrientation = c.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90,
            activeArray = active,
            capabilities = capInts.map { capName(it) },
            manualSensor = manualSensor,
            manualFocus = minFocus > 0f,
            rawSupported = capInts.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_RAW) && rawList.isNotEmpty(),
            tenBitAdvertised = Build.VERSION.SDK_INT >= 33 &&
                capInts.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_DYNAMIC_RANGE_TEN_BIT),
            flashAvailable = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true,
            isoRange = iso,
            exposureRangeNs = exp,
            minFocusDiopters = minFocus,
            zoomRange = if (Build.VERSION.SDK_INT >= 30) c.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE) else null,
            maxDigitalZoom = c.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM) ?: 1f,
            aeCompRange = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE) ?: Range(0, 0),
            aeCompStep = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)?.toFloat() ?: 0f,
            afModes = c.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)?.toList() ?: emptyList(),
            maxAfRegions = c.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF) ?: 0,
            maxAeRegions = c.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AE) ?: 0,
            fpsRanges = c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)?.toList() ?: emptyList(),
            noiseModes = c.get(CameraCharacteristics.NOISE_REDUCTION_AVAILABLE_NOISE_REDUCTION_MODES)?.toList() ?: emptyList(),
            edgeModes = c.get(CameraCharacteristics.EDGE_AVAILABLE_EDGE_MODES)?.toList() ?: emptyList(),
            stabilization = stab,
            photoSizes = photo,
            rawSizes = rawList,
            videoSizes = video
        )
    }

    /** Video modes that BOTH the camera and a hardware encoder report for the chosen codec. */
    fun videoModes(p: CameraProfile, hevc: Boolean): List<VideoMode> {
        val mime = if (hevc) MediaFormat.MIMETYPE_VIDEO_HEVC else MediaFormat.MIMETYPE_VIDEO_AVC
        val out = ArrayList<VideoMode>()
        for (vs in p.videoSizes) {
            for (fps in intArrayOf(60, 30, 24)) {
                if (fps > vs.maxFps) continue
                if (p.fpsRanges.none { it.lower <= fps && it.upper >= fps }) continue
                if (!Encoders.supports(mime, vs.size.width, vs.size.height, fps)) continue
                out.add(VideoMode(vs.size, fps))
            }
        }
        return out.sortedWith(
            compareByDescending<VideoMode> { it.size.width.toLong() * it.size.height }.thenByDescending { it.fps }
        )
    }

    fun hevcAvailable(): Boolean = Encoders.available(MediaFormat.MIMETYPE_VIDEO_HEVC)

    private fun sizeText(s: Size) = "${s.width}x${s.height}"

    fun report(): String = buildString {
        appendLine("NATIVE CAMERA - HARDWARE DIAGNOSTIC REPORT")
        appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL}")
        appendLine("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        appendLine("Build: ${Build.FINGERPRINT}")
        appendLine("Hardware H.264 encoder: ${Encoders.available(MediaFormat.MIMETYPE_VIDEO_AVC)}   HEVC: ${hevcAvailable()}")
        appendLine("Cameras found: ${profiles.size}")
        appendLine()
        appendLine("Values below are what the phone REPORTS. Version 0.1 does not run test")
        appendLine("recordings yet, so a reported mode can still fail on the phone.")
        for (p in profiles) {
            appendLine()
            appendLine("=== Camera ${p.id}: ${p.facing} ===")
            appendLine("Hardware level: ${p.hardwareLevel}")
            appendLine("Physical cameras behind it: ${if (p.physicalIds.isEmpty()) "none" else p.physicalIds.joinToString()}")
            appendLine("Focal lengths (mm): ${p.focalLengths.joinToString()}")
            appendLine("Sensor active array: ${p.activeArray.width()}x${p.activeArray.height()}  orientation ${p.sensorOrientation}")
            appendLine("Capabilities: ${p.capabilities.joinToString()}")
            appendLine("Manual ISO/shutter: ${p.manualSensor}" +
                (p.isoRange?.let { "   ISO ${it.lower}-${it.upper}" } ?: "") +
                (p.exposureRangeNs?.let { "   exposure ${it.lower}-${it.upper} ns" } ?: ""))
            appendLine("Manual focus: ${p.manualFocus}   Flash: ${p.flashAvailable}   Stabilization: ${if (p.stabilization.isEmpty()) "none reported" else p.stabilization.joinToString()}")
            appendLine("Zoom: ${p.zoomRange?.let { "${it.lower}x-${it.upper}x" } ?: "digital up to ${p.maxDigitalZoom}x"}")
            appendLine("RAW/DNG: ${p.rawSupported}   10-bit advertised: ${p.tenBitAdvertised} (not used by v0.1)")
            appendLine("Photo sizes (JPEG):")
            for (ph in p.photoSizes.sortedByDescending { it.size.width.toLong() * it.size.height }) {
                appendLine("  ${ratioLabel(ph.size.width, ph.size.height)}  ${ph.label}  (${sizeText(ph.size)})")
            }
            if (p.rawSizes.isNotEmpty()) {
                appendLine("RAW sizes:")
                for (r in p.rawSizes) appendLine("  ${r.label}  (${sizeText(r.size)})")
            }
            val h264 = videoModes(p, false)
            appendLine("Video modes, H.264: ${if (h264.isEmpty()) "none" else h264.joinToString { it.label + " (" + sizeText(it.size) + ")" }}")
            if (hevcAvailable()) {
                val hevc = videoModes(p, true)
                appendLine("Video modes, HEVC: ${if (hevc.isEmpty()) "none" else hevc.joinToString { it.label }}")
            }
            val has4k60 = h264.any { it.size.height >= 2160 && it.fps >= 60 } ||
                (hevcAvailable() && videoModes(p, true).any { it.size.height >= 2160 && it.fps >= 60 })
            appendLine("4K 60 FPS reported: $has4k60")
        }
    }

    fun toJson(): String {
        val root = JSONObject()
        root.put("device", "${Build.MANUFACTURER} ${Build.MODEL}")
        root.put("android", Build.VERSION.RELEASE)
        root.put("api", Build.VERSION.SDK_INT)
        root.put("fingerprint", Build.FINGERPRINT)
        root.put("hevcEncoder", hevcAvailable())
        val cams = JSONArray()
        for (p in profiles) {
            val o = JSONObject()
            o.put("id", p.id)
            o.put("facing", p.facing)
            o.put("hardwareLevel", p.hardwareLevel)
            o.put("capabilities", JSONArray(p.capabilities))
            o.put("manualSensor", p.manualSensor)
            o.put("manualFocus", p.manualFocus)
            o.put("raw", p.rawSupported)
            o.put("tenBitAdvertised", p.tenBitAdvertised)
            o.put("flash", p.flashAvailable)
            o.put("photoSizes", JSONArray(p.photoSizes.map { "${sizeText(it.size)}${if (it.fullRes) " full-res" else ""}" }))
            o.put("rawSizes", JSONArray(p.rawSizes.map { "${sizeText(it.size)}${if (it.fullRes) " full-res" else ""}" }))
            o.put("videoH264", JSONArray(videoModes(p, false).map { it.label + " " + sizeText(it.size) }))
            if (hevcAvailable()) o.put("videoHevc", JSONArray(videoModes(p, true).map { it.label + " " + sizeText(it.size) }))
            cams.put(o)
        }
        root.put("cameras", cams)
        return root.toString(2)
    }
}
