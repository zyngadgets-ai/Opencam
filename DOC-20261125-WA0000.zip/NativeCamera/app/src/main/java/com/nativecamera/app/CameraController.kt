package com.nativecamera.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.DngCreator
import android.hardware.camera2.TotalCaptureResult
import android.hardware.camera2.params.MeteringRectangle
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.hardware.camera2.params.StreamConfigurationMap
import android.media.Image
import android.media.ImageReader
import android.media.MediaCodec
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.Range
import android.util.Size
import android.view.Surface
import android.view.TextureView
import java.io.File
import java.io.FileDescriptor
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executor
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

enum class Mode { PHOTO, VIDEO }
enum class PhotoFormat(val label: String) { JPEG("JPEG"), DNG("DNG"), BOTH("JPEG+DNG") }
enum class FlashMode(val label: String) { OFF("Off"), AUTO("Auto"), ON("On"), TORCH("Torch") }

/** All callbacks arrive on the UI thread. */
interface CameraUi {
    fun onStatus(text: String)
    fun onError(text: String)
    fun onSaved(uri: Uri)
    fun onPreviewSize(width: Int, height: Int)
    fun onStateChanged()
    fun onRecording(recording: Boolean)
}

/**
 * Talks to the real camera hardware through Camera2. The app adds no filters or
 * enhancement of its own. Options come only from the hardware scan (Capabilities).
 */
class CameraController(
    private val activity: Activity,
    private val textureView: TextureView,
    private val ui: CameraUi
) {
    // ---------- state the UI reads (change it only through the functions below) ----------
    var profileIndex = 0
    var mode = Mode.PHOTO
    var photoFormat = PhotoFormat.JPEG
    var flashMode = FlashMode.OFF
    var useHevc = false
    var ratio = ""
    var sizeIndex = 0
    var zoom = 1f
    var evIndex = 0
    var minimalProcessing = true
    var manualExposure = false
    var iso = 100
    var exposureNs = 10_000_000L
    var manualFocus = false
    var focusDiopters = 0f
    @Volatile var deviceOrientation = 0
    @Volatile var recording = false
    @Volatile var paused = false
    @Volatile var lastIso = 100
    @Volatile var lastExposureNs = 10_000_000L

    val profile: CameraProfile get() = Capabilities.profiles[profileIndex]
    private val hasCameras: Boolean get() = Capabilities.profiles.isNotEmpty()

    // ---------- camera objects (touched on the camera thread) ----------
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var executor: Executor = Executor { it.run() }
    private var cameraDevice: CameraDevice? = null
    private var chars: CameraCharacteristics? = null
    private var map: StreamConfigurationMap? = null
    private var session: CameraCaptureSession? = null
    private var previewBuilder: CaptureRequest.Builder? = null
    private var previewSurface: Surface? = null
    private var jpegReader: ImageReader? = null
    private var rawReader: ImageReader? = null
    private var persistentSurface: Surface? = null
    private var recorder: MediaRecorder? = null
    private var recorderPfd: ParcelFileDescriptor? = null
    private var videoUri: Uri? = null
    private val videoCache = HashMap<String, List<VideoMode>>()

    // ---------- still-capture bookkeeping ----------
    private val lock = Any()
    private var busy = false
    private var expected = 0
    private var pendingRawImage: Image? = null
    private var pendingRawResult: TotalCaptureResult? = null
    private var shotStamp = ""
    private var shotOrientation = 0
    private var precaptureAction: (() -> Unit)? = null
    private var precaptureSeen = false

    // =====================================================================================
    // Options (all derived from the hardware scan)
    // =====================================================================================

    fun availableFormats(): List<PhotoFormat> =
        if (profile.rawSupported) listOf(PhotoFormat.JPEG, PhotoFormat.DNG, PhotoFormat.BOTH)
        else listOf(PhotoFormat.JPEG)

    private fun allPhotoOptions(): List<PhotoSize> {
        val p = profile
        val base = when (photoFormat) {
            PhotoFormat.JPEG -> p.photoSizes
            PhotoFormat.DNG -> p.rawSizes
            PhotoFormat.BOTH -> p.photoSizes.filter { !it.fullRes || p.rawSizes.any { r -> r.fullRes } }
        }
        return base.sortedByDescending { it.size.width.toLong() * it.size.height }
    }

    private fun allVideoOptions(): List<VideoMode> {
        val key = profile.id + "-" + useHevc
        return videoCache.getOrPut(key) { Capabilities.videoModes(profile, useHevc) }
    }

    fun ratios(): List<String> =
        (if (mode == Mode.PHOTO) allPhotoOptions().map { ratioLabel(it.size.width, it.size.height) }
        else allVideoOptions().map { ratioLabel(it.size.width, it.size.height) }).distinct()

    fun photoOptions(): List<PhotoSize> =
        allPhotoOptions().filter { ratioLabel(it.size.width, it.size.height) == ratio }

    fun videoOptions(): List<VideoMode> =
        allVideoOptions().filter { ratioLabel(it.size.width, it.size.height) == ratio }

    fun photoOption(): PhotoSize? = photoOptions().getOrNull(sizeIndex)
    fun videoOption(): VideoMode? = videoOptions().getOrNull(sizeIndex)

    fun optionCount(): Int = if (mode == Mode.PHOTO) photoOptions().size else videoOptions().size

    private fun rawFor(fullRes: Boolean): Size? =
        profile.rawSizes.filter { it.fullRes == fullRes }
            .maxByOrNull { it.size.width.toLong() * it.size.height }?.size

    fun hevcAvailable(): Boolean = Capabilities.hevcAvailable()

    fun minZoom(): Float = profile.zoomRange?.lower ?: 1f
    fun maxZoom(): Float = min(profile.zoomRange?.upper ?: profile.maxDigitalZoom, 20f)

    fun summary(): String =
        if (mode == Mode.PHOTO) "$ratio  |  ${photoOption()?.label ?: "no size"}  |  ${photoFormat.label}"
        else "$ratio  |  ${videoOption()?.label ?: "no mode"}  |  ${if (useHevc) "HEVC" else "H.264"}"

    private fun normalize() {
        if (!hasCameras) return
        if (!availableFormats().contains(photoFormat)) photoFormat = PhotoFormat.JPEG
        if (useHevc && !hevcAvailable()) useHevc = false
        val r = ratios()
        if (ratio !in r) {
            ratio = (if (mode == Mode.PHOTO) r.firstOrNull { it == "4:3" } else r.firstOrNull { it == "16:9" })
                ?: r.firstOrNull() ?: ""
        }
        sizeIndex = sizeIndex.coerceIn(0, max(0, optionCount() - 1))
    }

    // =====================================================================================
    // Functions the UI calls
    // =====================================================================================

    fun cycleCamera() {
        val n = Capabilities.profiles.size
        if (n < 2 || recording) return
        profileIndex = (profileIndex + 1) % n
        zoom = 1f.coerceIn(minZoom(), maxZoom())
        evIndex = 0
        manualExposure = false
        manualFocus = false
        ratio = ""
        sizeIndex = 0
        normalize()
        handler?.post {
            closeSession()
            cameraDevice?.close()
            cameraDevice = null
            openCamera()
        }
        ui.onStateChanged()
    }

    fun toggleMode() {
        if (recording) return
        mode = if (mode == Mode.PHOTO) Mode.VIDEO else Mode.PHOTO
        ratio = ""
        sizeIndex = 0
        normalize()
        reconfigure()
    }

    fun cycleFormat() {
        if (recording) return
        if (mode == Mode.PHOTO) {
            val f = availableFormats()
            photoFormat = f[(f.indexOf(photoFormat) + 1) % f.size]
        } else {
            if (!hevcAvailable()) return
            useHevc = !useHevc
        }
        ratio = ""
        sizeIndex = 0
        normalize()
        reconfigure()
    }

    fun cycleRatio() {
        if (recording) return
        val r = ratios()
        if (r.size < 2) return
        ratio = r[(r.indexOf(ratio) + 1) % r.size]
        sizeIndex = 0
        reconfigure()
    }

    fun cycleSize() {
        if (recording) return
        val n = optionCount()
        if (n < 2) return
        sizeIndex = (sizeIndex + 1) % n
        reconfigure()
    }

    fun cycleFlash() {
        if (!profile.flashAvailable) return
        val all = FlashMode.values()
        flashMode = all[(flashMode.ordinal + 1) % all.size]
        updatePreview()
        ui.onStateChanged()
    }

    fun setZoom(z: Float) {
        zoom = z.coerceIn(minZoom(), maxZoom())
        updatePreview()
    }

    fun setEv(index: Int) { evIndex = index; updatePreview() }
    fun setMinimal(on: Boolean) { minimalProcessing = on; updatePreview() }

    fun setManualExposure(on: Boolean) {
        manualExposure = on && profile.manualSensor
        if (manualExposure) { iso = lastIso; exposureNs = lastExposureNs }
        updatePreview()
    }

    fun setIso(v: Int) { iso = v; updatePreview() }
    fun setExposureNs(v: Long) { exposureNs = v; updatePreview() }

    fun setManualFocus(on: Boolean) {
        manualFocus = on && profile.manualFocus
        updatePreview()
    }

    fun setFocus(d: Float) { focusDiopters = d; updatePreview() }

    /** u, v: tap position inside the preview, each from 0 to 1 (as the user sees it, upright). */
    fun tapToFocus(u: Float, v: Float) {
        handler?.post {
            val b = previewBuilder
            val s = session
            val p = profile
            if (b == null || s == null || p.maxAfRegions == 0 || (manualFocus && p.manualFocus)) return@post
            val a = p.activeArray
            val crop = cropFor(zoom)
            val sx: Float
            val sy: Float
            when (p.sensorOrientation) {
                90 -> { sx = v; sy = 1f - u }
                180 -> { sx = 1f - u; sy = 1f - v }
                270 -> { sx = 1f - v; sy = u }
                else -> { sx = u; sy = v }
            }
            val half = (min(crop.width(), crop.height()) * 0.08f).toInt().coerceAtLeast(8)
            val cx = crop.left + (sx * crop.width()).toInt()
            val cy = crop.top + (sy * crop.height()).toInt()
            val left = (cx - half).coerceIn(a.left, a.right - 2 * half)
            val top = (cy - half).coerceIn(a.top, a.bottom - 2 * half)
            val region = MeteringRectangle(left, top, 2 * half, 2 * half, MeteringRectangle.METERING_WEIGHT_MAX - 1)
            try {
                b.set(CaptureRequest.CONTROL_AF_REGIONS, arrayOf(region))
                if (p.maxAeRegions > 0 && !manualExposure) b.set(CaptureRequest.CONTROL_AE_REGIONS, arrayOf(region))
                s.setRepeatingRequest(b.build(), previewCallback, handler)
                b.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_START)
                s.capture(b.build(), null, handler)
                b.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_IDLE)
                s.setRepeatingRequest(b.build(), previewCallback, handler)
                onUi { ui.onStatus("Focusing") }
            } catch (e: Exception) {
                onUi { ui.onError("Tap-to-focus failed: ${e.message}") }
            }
        }
    }

    fun takePhoto() {
        handler?.post {
            if (mode != Mode.PHOTO || session == null) return@post
            synchronized(lock) {
                if (busy) return@post
                busy = true
            }
            if ((flashMode == FlashMode.AUTO || flashMode == FlashMode.ON) && profile.flashAvailable) {
                runPrecapture { captureStill() }
            } else {
                captureStill()
            }
        }
    }

    fun startRecording() {
        handler?.post {
            if (mode != Mode.VIDEO || recording || session == null) return@post
            val vo = videoOption() ?: return@post
            try {
                val uri = newMedia("VID_${stamp()}.mp4", "video/mp4", MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
                videoUri = uri
                val pfd = activity.contentResolver.openFileDescriptor(uri, "w")
                    ?: throw IllegalStateException("Could not open the output file")
                recorderPfd = pfd
                val r = makeRecorder(vo, persistentSurface!!, false, pfd.fileDescriptor)
                recorder = r
                r.start()
                recording = true
                paused = false
                onUi { ui.onRecording(true) }
            } catch (e: Exception) {
                abortRecording()
                onUi { ui.onError("Could not start recording: ${e.message}") }
            }
        }
    }

    fun togglePause() {
        handler?.post {
            val r = recorder ?: return@post
            try {
                if (paused) r.resume() else r.pause()
                paused = !paused
                onUi { ui.onRecording(true) }
            } catch (e: Exception) {
                onUi { ui.onError("Pause failed: ${e.message}") }
            }
        }
    }

    fun stopRecording() {
        handler?.post { finishRecording() }
    }

    // =====================================================================================
    // Lifecycle
    // =====================================================================================

    fun start() {
        if (thread != null) return
        val t = HandlerThread("camera").also { it.start() }
        thread = t
        val h = Handler(t.looper)
        handler = h
        executor = Executor { h.post(it) }
        normalize()
        textureView.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(s: SurfaceTexture, w: Int, h2: Int) { handler?.post { openCamera() } }
            override fun onSurfaceTextureSizeChanged(s: SurfaceTexture, w: Int, h2: Int) {}
            override fun onSurfaceTextureDestroyed(s: SurfaceTexture): Boolean = true
            override fun onSurfaceTextureUpdated(s: SurfaceTexture) {}
        }
        if (textureView.isAvailable) h.post { openCamera() }
    }

    fun stop() {
        val t = thread ?: return
        handler?.post {
            closeSession()
            cameraDevice?.close()
            cameraDevice = null
        }
        t.quitSafely()
        try { t.join() } catch (e: InterruptedException) { }
        thread = null
        handler = null
    }

    // =====================================================================================
    // Camera + session
    // =====================================================================================

    @SuppressLint("MissingPermission")
    private fun openCamera() {
        if (!hasCameras) { onUi { ui.onError("No usable camera was found on this phone") }; return }
        if (activity.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return
        if (cameraDevice != null) return
        try {
            val mgr = activity.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val p = profile
            val c = mgr.getCameraCharacteristics(p.id)
            chars = c
            map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            mgr.openCamera(p.id, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) { cameraDevice = camera; startSession() }
                override fun onDisconnected(camera: CameraDevice) { camera.close(); cameraDevice = null }
                override fun onError(camera: CameraDevice, error: Int) {
                    camera.close()
                    cameraDevice = null
                    onUi { ui.onError("Camera error $error (another app may be using the camera)") }
                }
            }, handler)
        } catch (e: Exception) {
            onUi { ui.onError("Could not open the camera: ${e.message}") }
        }
    }

    private fun reconfigure() {
        handler?.post { startSession() }
        ui.onStateChanged()
    }

    private fun choosePreviewSize(): Size {
        val sizes = map!!.getOutputSizes(SurfaceTexture::class.java).toList()
        val target = (if (mode == Mode.PHOTO) photoOption()?.size else videoOption()?.size) ?: sizes.first()
        val tr = target.width.toDouble() / target.height
        val matching = sizes.filter { abs(it.width.toDouble() / it.height - tr) < 0.02 }
        val pool = if (matching.isNotEmpty()) matching else sizes
        return pool.filter { it.width * it.height <= 2_100_000 }.maxByOrNull { it.width * it.height }
            ?: pool.minByOrNull { it.width * it.height }!!
    }

    private fun outputFor(surface: Surface, fullRes: Boolean): OutputConfiguration {
        val oc = OutputConfiguration(surface)
        if (fullRes && Build.VERSION.SDK_INT >= 31) {
            oc.addSensorPixelModeUsed(CameraMetadata.SENSOR_PIXEL_MODE_MAXIMUM_RESOLUTION)
        }
        return oc
    }

    private fun startSession() {
        val cam = cameraDevice ?: return
        closeSession()
        try {
            normalize()
            val st = textureView.surfaceTexture ?: return
            val ps = choosePreviewSize()
            st.setDefaultBufferSize(ps.width, ps.height)
            onUi { ui.onPreviewSize(ps.width, ps.height) }
            val pSurface = Surface(st)
            previewSurface = pSurface
            val outs = ArrayList<OutputConfiguration>()
            outs.add(OutputConfiguration(pSurface))

            if (mode == Mode.PHOTO) {
                val opt = photoOption() ?: throw IllegalStateException("This camera reports no photo sizes")
                if (photoFormat != PhotoFormat.DNG) {
                    val r = ImageReader.newInstance(opt.size.width, opt.size.height, ImageFormat.JPEG, 2)
                    r.setOnImageAvailableListener({ rd -> onJpeg(rd) }, handler)
                    jpegReader = r
                    outs.add(outputFor(r.surface, opt.fullRes))
                }
                if (photoFormat != PhotoFormat.JPEG) {
                    val rs = rawFor(opt.fullRes) ?: throw IllegalStateException("RAW is not reported at this size")
                    val r = ImageReader.newInstance(rs.width, rs.height, ImageFormat.RAW_SENSOR, 2)
                    r.setOnImageAvailableListener({ rd -> onRaw(rd) }, handler)
                    rawReader = r
                    outs.add(outputFor(r.surface, opt.fullRes))
                }
            } else {
                val vo = videoOption() ?: throw IllegalStateException("This camera reports no video modes")
                val surface = MediaCodec.createPersistentInputSurface()
                persistentSurface = surface
                // Prepare and release one recorder so the surface gets its size before the session starts.
                makeRecorder(vo, surface, true, null).release()
                outs.add(OutputConfiguration(surface))
            }

            val cfg = SessionConfiguration(
                SessionConfiguration.SESSION_REGULAR, outs, executor,
                object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(s: CameraCaptureSession) {
                        session = s
                        refreshPreview()
                        onUi { ui.onStatus(summary()) }
                    }

                    override fun onConfigureFailed(s: CameraCaptureSession) {
                        onUi { ui.onError("This phone cannot run this combination (${summary()}). Choose another option.") }
                    }
                }
            )
            cam.createCaptureSession(cfg)
        } catch (e: Exception) {
            onUi { ui.onError("Could not start the camera: ${e.message}") }
        }
    }

    private fun closeSession() {
        if (recording) finishRecording()
        try { session?.close() } catch (e: Exception) { }
        session = null
        previewBuilder = null
        jpegReader?.close(); jpegReader = null
        rawReader?.close(); rawReader = null
        persistentSurface?.release(); persistentSurface = null
        previewSurface?.release(); previewSurface = null
        synchronized(lock) {
            pendingRawImage?.close()
            pendingRawImage = null
            pendingRawResult = null
            busy = false
            expected = 0
        }
    }

    // =====================================================================================
    // Preview request
    // =====================================================================================

    private val previewCallback = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(s: CameraCaptureSession, request: CaptureRequest, result: TotalCaptureResult) {
            result.get(CaptureResult.SENSOR_SENSITIVITY)?.let { lastIso = it }
            result.get(CaptureResult.SENSOR_EXPOSURE_TIME)?.let { lastExposureNs = it }
        }
    }

    private fun updatePreview() { handler?.post { refreshPreview() } }

    private fun refreshPreview() {
        val cam = cameraDevice ?: return
        val s = session ?: return
        val surface = previewSurface ?: return
        try {
            val b = cam.createCaptureRequest(if (mode == Mode.VIDEO) CameraDevice.TEMPLATE_RECORD else CameraDevice.TEMPLATE_PREVIEW)
            b.addTarget(surface)
            if (mode == Mode.VIDEO) persistentSurface?.let { b.addTarget(it) }
            applyCommon(b, false, false)
            previewBuilder = b
            s.setRepeatingRequest(b.build(), previewCallback, handler)
        } catch (e: Exception) {
            onUi { ui.onError("Preview error: ${e.message}") }
        }
    }

    private fun cropFor(z: Float): Rect {
        val a = profile.activeArray
        if (z <= 1f) return a
        val w = (a.width() / z).toInt()
        val h = (a.height() / z).toInt()
        val x = a.centerX() - w / 2
        val y = a.centerY() - h / 2
        return Rect(x, y, x + w, y + h)
    }

    private fun currentFps(): Int = videoOption()?.fps ?: 30

    private fun pickFpsRange(fps: Int): Range<Int>? {
        val r = profile.fpsRanges
        return r.firstOrNull { it.lower == fps && it.upper == fps }
            ?: r.filter { it.upper == fps }.maxByOrNull { it.lower }
            ?: r.filter { it.upper > fps && it.lower <= fps }.minByOrNull { it.upper }
    }

    private fun aeModeFor(still: Boolean): Int {
        if (!profile.flashAvailable || mode == Mode.VIDEO || !still) return CameraMetadata.CONTROL_AE_MODE_ON
        return when (flashMode) {
            FlashMode.AUTO -> CameraMetadata.CONTROL_AE_MODE_ON_AUTO_FLASH
            FlashMode.ON -> CameraMetadata.CONTROL_AE_MODE_ON_ALWAYS_FLASH
            else -> CameraMetadata.CONTROL_AE_MODE_ON
        }
    }

    /** Settings shared by preview and still requests. No creative processing is requested. */
    private fun applyCommon(b: CaptureRequest.Builder, still: Boolean, fullRes: Boolean) {
        val p = profile
        b.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)

        // Focus
        if (manualFocus && p.manualFocus) {
            b.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_OFF)
            b.set(CaptureRequest.LENS_FOCUS_DISTANCE, focusDiopters)
        } else {
            val want = if (mode == Mode.VIDEO) CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_VIDEO
            else CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_PICTURE
            if (p.afModes.contains(want)) b.set(CaptureRequest.CONTROL_AF_MODE, want)
            else if (p.afModes.contains(CameraMetadata.CONTROL_AF_MODE_AUTO)) b.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_AUTO)
        }

        // Exposure
        if (manualExposure && p.manualSensor) {
            b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_OFF)
            b.set(CaptureRequest.SENSOR_SENSITIVITY, iso)
            val longest = if (mode == Mode.VIDEO) 1_000_000_000L / currentFps() else Long.MAX_VALUE
            b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, min(exposureNs, longest))
        } else {
            b.set(CaptureRequest.CONTROL_AE_MODE, aeModeFor(still))
            b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, evIndex)
        }

        // Flash / torch
        b.set(
            CaptureRequest.FLASH_MODE,
            if (flashMode == FlashMode.TORCH && p.flashAvailable) CameraMetadata.FLASH_MODE_TORCH
            else CameraMetadata.FLASH_MODE_OFF
        )

        // Zoom (skipped for full-resolution stills, which use the other pixel mode)
        if (!fullRes) {
            if (Build.VERSION.SDK_INT >= 30 && p.zoomRange != null) {
                b.set(CaptureRequest.CONTROL_ZOOM_RATIO, zoom)
            } else {
                b.set(CaptureRequest.SCALER_CROP_REGION, cropFor(zoom))
            }
        }

        // Frame rate for video
        if (mode == Mode.VIDEO && !still) {
            pickFpsRange(currentFps())?.let { b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, it) }
        }

        // Minimal processing: ask the camera pipeline to do as little as the phone allows.
        // Some phones ignore these requests.
        if (minimalProcessing) {
            val nr = when {
                p.noiseModes.contains(CameraMetadata.NOISE_REDUCTION_MODE_MINIMAL) -> CameraMetadata.NOISE_REDUCTION_MODE_MINIMAL
                p.noiseModes.contains(CameraMetadata.NOISE_REDUCTION_MODE_OFF) -> CameraMetadata.NOISE_REDUCTION_MODE_OFF
                else -> null
            }
            if (nr != null) b.set(CaptureRequest.NOISE_REDUCTION_MODE, nr)
            if (p.edgeModes.contains(CameraMetadata.EDGE_MODE_OFF)) b.set(CaptureRequest.EDGE_MODE, CameraMetadata.EDGE_MODE_OFF)
        }
    }

    // =====================================================================================
    // Photo
    // =====================================================================================

    private fun jpegOrientation(): Int {
        val sign = if (profile.facing == "Front") -1 else 1
        return (profile.sensorOrientation + deviceOrientation * sign + 360) % 360
    }

    private fun exifCode(deg: Int): Int = when (deg) {
        90 -> 6
        180 -> 3
        270 -> 8
        else -> 1
    }

    private fun runPrecapture(then: () -> Unit) {
        val b = previewBuilder
        val s = session
        if (b == null || s == null) { then(); return }
        precaptureAction = then
        precaptureSeen = false
        try {
            b.set(CaptureRequest.CONTROL_AE_PRECAPTURE_TRIGGER, CameraMetadata.CONTROL_AE_PRECAPTURE_TRIGGER_START)
            s.capture(b.build(), object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureCompleted(ss: CameraCaptureSession, request: CaptureRequest, result: TotalCaptureResult) {
                    val ae = result.get(CaptureResult.CONTROL_AE_STATE)
                    if (ae == CameraMetadata.CONTROL_AE_STATE_PRECAPTURE) precaptureSeen = true
                    else if (precaptureSeen || ae == null) firePrecapture()
                }
            }, handler)
            b.set(CaptureRequest.CONTROL_AE_PRECAPTURE_TRIGGER, CameraMetadata.CONTROL_AE_PRECAPTURE_TRIGGER_IDLE)
            handler?.postDelayed({ firePrecapture() }, 1500)
        } catch (e: Exception) {
            firePrecapture()
        }
    }

    private fun firePrecapture() {
        val a = precaptureAction ?: return
        precaptureAction = null
        a()
    }

    private fun captureStill() {
        val cam = cameraDevice
        val s = session
        val opt = photoOption()
        if (cam == null || s == null || opt == null) { synchronized(lock) { busy = false }; return }
        try {
            val b = cam.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
            jpegReader?.let { b.addTarget(it.surface) }
            rawReader?.let { b.addTarget(it.surface) }
            applyCommon(b, true, opt.fullRes)
            if (opt.fullRes && Build.VERSION.SDK_INT >= 31) {
                b.set(CaptureRequest.SENSOR_PIXEL_MODE, CameraMetadata.SENSOR_PIXEL_MODE_MAXIMUM_RESOLUTION)
            }
            shotOrientation = jpegOrientation()
            b.set(CaptureRequest.JPEG_ORIENTATION, shotOrientation)
            b.set(CaptureRequest.JPEG_QUALITY, 100.toByte())
            shotStamp = stamp()
            synchronized(lock) {
                pendingRawImage?.close()
                pendingRawImage = null
                pendingRawResult = null
                expected = (if (jpegReader != null) 1 else 0) + (if (rawReader != null) 1 else 0)
            }
            s.capture(b.build(), stillCallback, handler)
        } catch (e: Exception) {
            synchronized(lock) { busy = false; expected = 0 }
            onUi { ui.onError("Capture failed: ${e.message}") }
        }
    }

    private val stillCallback = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(s: CameraCaptureSession, request: CaptureRequest, result: TotalCaptureResult) {
            synchronized(lock) { pendingRawResult = result }
            tryWriteDng()
        }

        override fun onCaptureFailed(s: CameraCaptureSession, request: CaptureRequest, failure: android.hardware.camera2.CaptureFailure) {
            synchronized(lock) { busy = false; expected = 0 }
            onUi { ui.onError("The camera could not take that picture") }
        }
    }

    private fun savedOne() {
        synchronized(lock) {
            if (expected > 0) expected--
            if (expected == 0) busy = false
        }
    }

    private fun onJpeg(reader: ImageReader) {
        val img = reader.acquireNextImage() ?: return
        try {
            val buf = img.planes[0].buffer
            val bytes = ByteArray(buf.remaining())
            buf.get(bytes)
            val uri = newMedia("IMG_$shotStamp.jpg", "image/jpeg", MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            activity.contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
            finishMedia(uri)
            onUi { ui.onSaved(uri) }
        } catch (e: Exception) {
            onUi { ui.onError("Could not save the photo: ${e.message}") }
        } finally {
            img.close()
            savedOne()
        }
    }

    private fun onRaw(reader: ImageReader) {
        val img = reader.acquireNextImage() ?: return
        synchronized(lock) {
            pendingRawImage?.close()
            pendingRawImage = img
        }
        tryWriteDng()
    }

    private fun tryWriteDng() {
        val img: Image
        val result: TotalCaptureResult
        synchronized(lock) {
            if (rawReader == null) return
            img = pendingRawImage ?: return
            result = pendingRawResult ?: return
            pendingRawImage = null
            pendingRawResult = null
        }
        try {
            val c = chars ?: throw IllegalStateException("camera information missing")
            val uri = newMedia("RAW_$shotStamp.dng", "image/x-adobe-dng", MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            val dng = DngCreator(c, result)
            dng.setOrientation(exifCode(shotOrientation))
            activity.contentResolver.openOutputStream(uri)!!.use { dng.writeImage(it, img) }
            dng.close()
            finishMedia(uri)
            onUi { ui.onSaved(uri) }
        } catch (e: Exception) {
            onUi { ui.onError("Could not save the RAW file: ${e.message}") }
        } finally {
            img.close()
            savedOne()
        }
    }

    // =====================================================================================
    // Video
    // =====================================================================================

    private fun bitrateFor(vo: VideoMode): Int {
        val bitsPerPixel = if (useHevc) 0.14 else 0.20
        val b = vo.size.width.toDouble() * vo.size.height * vo.fps * bitsPerPixel
        return b.toLong().coerceIn(2_000_000L, 120_000_000L).toInt()
    }

    @Suppress("DEPRECATION")
    private fun makeRecorder(vo: VideoMode, surface: Surface, dummy: Boolean, fd: FileDescriptor?): MediaRecorder {
        val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(activity) else MediaRecorder()
        val audio = !dummy &&
            activity.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (audio) r.setAudioSource(MediaRecorder.AudioSource.MIC)
        r.setVideoSource(MediaRecorder.VideoSource.SURFACE)
        r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        if (dummy) r.setOutputFile(File(activity.cacheDir, "probe.mp4").absolutePath) else r.setOutputFile(fd!!)
        r.setVideoEncodingBitRate(bitrateFor(vo))
        r.setVideoFrameRate(vo.fps)
        r.setVideoSize(vo.size.width, vo.size.height)
        r.setVideoEncoder(if (useHevc) MediaRecorder.VideoEncoder.HEVC else MediaRecorder.VideoEncoder.H264)
        if (audio) {
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(192_000)
            r.setAudioSamplingRate(48_000)
        }
        if (!dummy) r.setOrientationHint(jpegOrientation())
        r.setInputSurface(surface)
        r.prepare()
        return r
    }

    private fun abortRecording() {
        try { recorder?.release() } catch (e: Exception) { }
        recorder = null
        try { recorderPfd?.close() } catch (e: Exception) { }
        recorderPfd = null
        videoUri?.let { try { activity.contentResolver.delete(it, null, null) } catch (e: Exception) { } }
        videoUri = null
        recording = false
        paused = false
        onUi { ui.onRecording(false) }
    }

    private fun finishRecording() {
        val r = recorder ?: return
        val uri = videoUri
        var ok = true
        try { r.stop() } catch (e: RuntimeException) { ok = false }
        try { r.release() } catch (e: Exception) { }
        recorder = null
        try { recorderPfd?.close() } catch (e: Exception) { }
        recorderPfd = null
        videoUri = null
        recording = false
        paused = false
        if (uri != null) {
            if (ok) {
                finishMedia(uri)
                onUi { ui.onSaved(uri) }
            } else {
                try { activity.contentResolver.delete(uri, null, null) } catch (e: Exception) { }
                onUi { ui.onError("The recording was too short to save") }
            }
        }
        onUi { ui.onRecording(false) }
    }

    // =====================================================================================
    // Saving helpers
    // =====================================================================================

    private fun stamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun newMedia(name: String, mime: String, collection: Uri): Uri {
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, "DCIM/NativeCamera")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        return activity.contentResolver.insert(collection, cv)
            ?: throw IllegalStateException("MediaStore could not create the file")
    }

    private fun finishMedia(uri: Uri) {
        val cv = ContentValues()
        cv.put(MediaStore.MediaColumns.IS_PENDING, 0)
        activity.contentResolver.update(uri, cv, null, null)
    }

    private fun onUi(f: () -> Unit) { activity.runOnUiThread { f() } }
}
