package com.nativecamera.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Shows what the hardware scan found, lets you re-scan and share the report. */
class DiagnosticsActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val reportView = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 11f
            setTextColor(Color.WHITE)
            setPadding(24, 24, 24, 24)
            setTextIsSelectable(true)
            this.text = Capabilities.report()
        }

        val rescan = Button(this).apply {
            this.text = "Re-scan"
            setOnClickListener {
                Capabilities.scan(this@DiagnosticsActivity)
                reportView.text = Capabilities.report()
            }
        }
        val share = Button(this).apply {
            this.text = "Share report"
            setOnClickListener {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "Native Camera hardware report")
                    putExtra(Intent.EXTRA_TEXT, Capabilities.toJson())
                }
                startActivity(Intent.createChooser(send, "Share hardware report"))
            }
        }
        val close = Button(this).apply {
            this.text = "Back"
            setOnClickListener { finish() }
        }

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            addView(rescan, lp)
            addView(share, lp)
            addView(close, lp)
        }

        val scroll = ScrollView(this).apply { addView(reportView) }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            addView(buttons, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        applySystemBarPadding(root)
        setContentView(root)
    }
}
