package com.nativecamera.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.GestureDetector
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.OrientationEventListener
import android.view.ScaleGestureDetector
import android.view.TextureView
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

class MainActivity : Activity(), CameraUi {

    private lateinit var controller: CameraController
    private lateinit var preview: TextureView
    private lateinit var grid: GridOverlay
    private lateinit var status: TextView
    private lateinit var countdownView: TextView
    private lateinit var proPanel: View
    private lateinit var btnFlash: Button
    private lateinit var btnRatio: Button
    private lateinit var btnSize: Button
    private lateinit var btnTimer: Button
    private lateinit var btnGrid: Button
    private lateinit var btnMode: Button
    private lateinit var btnFormat: Button
    private lateinit var btnLens: Button
    private lateinit var btnPro: Button
    private lateinit var btnShutter: Button
    private lateinit var btnPause: Button
    private lateinit var chkManualExp: CheckBox
    private lateinit var chkManualFocus: CheckBox
    private lateinit var chkMinimal: CheckBox
    private lateinit var seekEv: SeekBar
    private lateinit var seekIso: SeekBar
    private lateinit var seekShutter: SeekBar
    private lateinit var seekFocus: SeekBar
    private lateinit var txtEv: TextView
    private lateinit var txtIso: TextView
    private lateinit var txtShutter: TextView
    private lateinit var txtFocus: TextView
    private lateinit var orientationListener: OrientationEventListener
    private lateinit var scaleDetector: ScaleGestureDetector
    private lateinit var tapDetector: GestureDetector

    private val uiHandler = Handler(Looper.getMainLooper())
    private var timerSeconds = 0
    private var countingDown = false
    private var gridOn = false
    private var lastUri: Uri? = null
    private var askedPermissions = false
    private var started = false
    private var haveCameras = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)
        applySystemBarPadding(findViewById(R.id.root))

        preview = findViewById(R.id.preview)
        grid = findViewById(R.id.grid)
        status = findViewById(R.id.status)
        countdownView = findViewById(R.id.countdown)
        proPanel = findViewById(R.id.proPanel)
        btnFlash = findViewById(R.id.btnFlash)
        btnRatio = findViewById(R.id.btnRatio)
        btnSize = findViewById(R.id.btnSize)
        btnTimer = findViewById(R.id.btnTimer)
        btnGrid = findViewById(R.id.btnGrid)
        btnMode = findViewById(R.id.btnMode)
        btnFormat = findViewById(R.id.btnFormat)
        btnLens = findViewById(R.id.btnLens)
        btnPro = findViewById(R.id.btnPro)
        btnShutter = findViewById(R.id.btnShutter)
        btnPause = findViewById(R.id.btnPause)
        chkManualExp = findViewById(R.id.chkManualExp)
        chkManualFocus = findViewById(R.id.chkManualFocus)
        chkMinimal = findViewById(R.id.chkMinimal)
        seekEv = findViewById(R.id.seekEv)
        seekIso = findViewById(R.id.seekIso)
        seekShutter = findViewById(R.id.seekShutter)
        seekFocus = findViewById(R.id.seekFocus)
        txtEv = findViewById(R.id.txtEv)
        txtIso = findViewById(R.id.txtIso)
        txtShutter = findViewById(R.id.txtShutter)
        txtFocus = findViewById(R.id.txtFocus)

        // The hardware diagnostic scan runs first. Everything on screen comes from its result.
        try { Capabilities.scan(this) } catch (e: Exception) { /* handled below */ }
        haveCameras = Capabilities.profiles.isNotEmpty()

        controller = CameraController(this, preview, this)
        orientationListener = object : OrientationEventListener(this) {
            override fun onOrientationChanged(o: Int) {
                if (o != ORIENTATION_UNKNOWN) controller.deviceOrientation = ((o + 45) / 90 * 90) % 360
            }
        }
        setupGestures()
        setupButtons()
        setupProControls()

        if (!haveCameras) {
            status.text = "No usable camera found"
            status.visibility = View.VISIBLE
        }
        refresh()
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onResume() {
        super.onResume()
        orientationListener.enable()
        if (!haveCameras) return
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else if (!askedPermissions) {
            askedPermissions = true
            requestPermissions(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO), 10)
        } else {
            status.text = "Camera permission is needed to use this app"
        }
    }

    override fun onPause() {
        super.onPause()
        orientationListener.disable()
        cancelCountdown()
        if (started) {
            controller.stop()
            started = false
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            status.text = "Camera permission is needed to use this app"
        }
    }

    private fun startCamera() {
        if (started) return
        started = true
        controller.start()
        refresh()
    }

    // ---------------------------------------------------------------- gestures and keys

    private fun setupGestures() {
        scaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                controller.setZoom(controller.zoom * d.scaleFactor)
                status.text = String.format("Zoom %.1fx", controller.zoom)
                return true
            }
        })
        tapDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                if (preview.width > 0 && preview.height > 0) {
                    controller.tapToFocus(e.x / preview.width, e.y / preview.height)
                }
                return true
            }
        })
        preview.setOnTouchListener { _, ev ->
            scaleDetector.onTouchEvent(ev)
            if (!scaleDetector.isInProgress) tapDetector.onTouchEvent(ev)
            true
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            if (event?.repeatCount == 0) onShutter()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    // ---------------------------------------------------------------- buttons

    private fun setupButtons() {
        btnShutter.setOnClickListener { onShutter() }
        btnMode.setOnClickListener { controller.toggleMode() }
        btnFormat.setOnClickListener { controller.cycleFormat() }
        btnLens.setOnClickListener { controller.cycleCamera() }
        btnRatio.setOnClickListener { controller.cycleRatio() }
        btnSize.setOnClickListener { controller.cycleSize() }
        btnFlash.setOnClickListener { controller.cycleFlash() }
        btnPause.setOnClickListener { controller.togglePause() }
        btnTimer.setOnClickListener {
            timerSeconds = when (timerSeconds) { 0 -> 3; 3 -> 10; else -> 0 }
            refresh()
        }
        btnGrid.setOnClickListener {
            gridOn = !gridOn
            grid.visibility = if (gridOn) View.VISIBLE else View.GONE
            refresh()
        }
        btnPro.setOnClickListener {
            proPanel.visibility = if (proPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            refreshPro()
        }
        btnScan.setOnClickListener { startActivity(Intent(this, DiagnosticsActivity::class.java)) }
        findViewById<Button>(R.id.btnGallery).setOnClickListener { openGallery() }
    }

    private val btnScan: Button get() = findViewById(R.id.btnScan)

    private fun onShutter() {
        if (!haveCameras || !started) return
        if (controller.mode == Mode.VIDEO && controller.recording) {
            controller.stopRecording()
            return
        }
        if (countingDown) {
            cancelCountdown()
            return
        }
        if (timerSeconds > 0) {
            countingDown = true
            countdown(timerSeconds)
        } else {
            fireShutter()
        }
    }

    private fun countdown(n: Int) {
        if (!countingDown) return
        if (n <= 0) {
            fireShutter()
            return
        }
        countdownView.text = n.toString()
        countdownView.visibility = View.VISIBLE
        uiHandler.postDelayed({ countdown(n - 1) }, 1000)
    }

    private fun cancelCountdown() {
        countingDown = false
        uiHandler.removeCallbacksAndMessages(null)
        countdownView.visibility = View.GONE
    }

    private fun fireShutter() {
        countingDown = false
        countdownView.visibility = View.GONE
        if (controller.mode == Mode.PHOTO) controller.takePhoto() else controller.startRecording()
    }

    private fun openGallery() {
        val uri = lastUri
        try {
            val i = Intent(Intent.ACTION_VIEW)
            if (uri != null) i.setDataAndType(uri, contentResolver.getType(uri))
            else i.data = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "No gallery app could open this", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------------------------------------------------------------- pro controls

    private fun SeekBar.onChange(f: (Int) -> Unit) {
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) { if (fromUser) f(p) }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
    }

    private fun setupProControls() {
        seekEv.onChange { p ->
            val r = controller.profile.aeCompRange
            controller.setEv(p + r.lower)
            refreshProText()
        }
        chkManualExp.setOnCheckedChangeListener { _, on ->
            controller.setManualExposure(on)
            if (controller.manualExposure) {
                seekIso.progress = progressFromIso(controller.iso)
                seekShutter.progress = progressFromShutter(controller.exposureNs)
            }
            refreshPro()
        }
        seekIso.onChange { p ->
            if (controller.manualExposure) controller.setIso(isoFromProgress(p))
            refreshProText()
        }
        seekShutter.onChange { p ->
            if (controller.manualExposure) controller.setExposureNs(shutterFromProgress(p))
            refreshProText()
        }
        chkManualFocus.setOnCheckedChangeListener { _, on ->
            controller.setManualFocus(on)
            refreshPro()
        }
        seekFocus.onChange { p ->
            if (controller.manualFocus) controller.setFocus(p / 1000f * controller.profile.minFocusDiopters)
            refreshProText()
        }
        chkMinimal.setOnCheckedChangeListener { _, on -> controller.setMinimal(on) }
    }

    private fun isoFromProgress(p: Int): Int {
        val r = controller.profile.isoRange ?: return 100
        val lo = max(1, r.lower).toDouble()
        return (lo * (r.upper / lo).pow(p / 1000.0)).toInt().coerceIn(r.lower, r.upper)
    }

    private fun progressFromIso(iso: Int): Int {
        val r = controller.profile.isoRange ?: return 0
        val lo = max(1, r.lower).toDouble()
        if (r.upper <= lo) return 0
        return (1000 * ln(max(iso.toDouble(), lo) / lo) / ln(r.upper / lo)).toInt().coerceIn(0, 1000)
    }

    private fun shutterRange(): Pair<Double, Double> {
        val r = controller.profile.exposureRangeNs ?: return Pair(1e6, 1e6)
        return Pair(max(1L, r.lower).toDouble(), min(r.upper, 1_000_000_000L).toDouble())
    }

    private fun shutterFromProgress(p: Int): Long {
        val (lo, hi) = shutterRange()
        if (hi <= lo) return lo.toLong()
        return (lo * (hi / lo).pow(p / 1000.0)).toLong()
    }

    private fun progressFromShutter(ns: Long): Int {
        val (lo, hi) = shutterRange()
        if (hi <= lo) return 0
        return (1000 * ln(max(ns.toDouble(), lo) / lo) / ln(hi / lo)).toInt().coerceIn(0, 1000)
    }

    private fun shutterText(ns: Long): String =
        if (ns >= 400_000_000L) String.format("%.1fs", ns / 1e9) else "1/" + (1e9 / ns).roundToInt() + "s"

    private fun refreshProText() {
        if (!haveCameras) return
        val p = controller.profile
        txtEv.text = String.format("Exposure compensation %+.1f EV", controller.evIndex * p.aeCompStep)
        txtIso.text = "ISO " + (if (controller.manualExposure) controller.iso else controller.lastIso) +
            (if (controller.manualExposure) "" else " (auto)")
        txtShutter.text = "Shutter " +
            shutterText(if (controller.manualExposure) controller.exposureNs else controller.lastExposureNs) +
            (if (controller.manualExposure) "" else " (auto)")
        txtFocus.text = if (!controller.manualFocus) "Focus: auto"
        else if (controller.focusDiopters <= 0.01f) "Focus: infinity"
        else String.format("Focus: %.2f m", 1f / controller.focusDiopters)
    }

    /** Options the phone cannot do are switched off with a short reason. */
    private fun refreshPro() {
        if (!haveCameras) return
        val p = controller.profile
        val r = p.aeCompRange
        seekEv.max = r.upper - r.lower
        seekEv.progress = controller.evIndex - r.lower
        seekEv.isEnabled = r.upper > r.lower
        chkManualExp.isEnabled = p.manualSensor
        chkManualExp.text = if (p.manualSensor) "Manual ISO / shutter" else "Manual ISO / shutter (not supported by this camera)"
        chkManualExp.isChecked = controller.manualExposure
        seekIso.isEnabled = controller.manualExposure
        seekShutter.isEnabled = controller.manualExposure
        chkManualFocus.isEnabled = p.manualFocus
        chkManualFocus.text = if (p.manualFocus) "Manual focus" else "Manual focus (not supported by this camera)"
        chkManualFocus.isChecked = controller.manualFocus
        seekFocus.isEnabled = controller.manualFocus
        refreshProText()
    }

    // ---------------------------------------------------------------- labels

    private fun refresh() {
        if (!haveCameras) return
        val c = controller
        val p = c.profile
        val video = c.mode == Mode.VIDEO

        btnMode.text = if (video) "Mode: Video" else "Mode: Photo"
        btnLens.text = p.label
        btnRatio.text = "Ratio " + c.ratio
        btnRatio.isEnabled = c.ratios().size > 1 && !c.recording
        btnSize.text = if (video) (c.videoOption()?.label ?: "-") else (c.photoOption()?.label ?: "-")
        btnSize.isEnabled = c.optionCount() > 1 && !c.recording
        btnFormat.text = if (video) (if (c.useHevc) "HEVC" else "H.264") else c.photoFormat.label
        btnFormat.isEnabled = !c.recording && (if (video) c.hevcAvailable() else c.availableFormats().size > 1)
        btnFlash.text = if (p.flashAvailable) "Flash " + c.flashMode.label else "No flash"
        btnFlash.isEnabled = p.flashAvailable
        btnTimer.text = if (timerSeconds == 0) "Timer off" else "Timer ${timerSeconds}s"
        btnGrid.text = if (gridOn) "Grid on" else "Grid off"
        btnLens.isEnabled = Capabilities.profiles.size > 1 && !c.recording
        btnMode.isEnabled = !c.recording
        btnShutter.setBackgroundResource(if (c.recording) R.drawable.shutter_rec else R.drawable.shutter)
        btnPause.visibility = if (c.recording) View.VISIBLE else View.INVISIBLE
        btnPause.text = if (c.paused) "Resume" else "Pause"
        if (proPanel.visibility == View.VISIBLE) refreshPro()
    }

    // ---------------------------------------------------------------- CameraUi callbacks (UI thread)

    override fun onStatus(text: String) {
        status.text = text
        status.visibility = View.VISIBLE
        refresh()
    }

    override fun onError(text: String) {
        status.text = text
        status.visibility = View.VISIBLE
        Toast.makeText(this, text, Toast.LENGTH_LONG).show()
        refresh()
    }

    override fun onSaved(uri: Uri) {
        lastUri = uri
        status.text = "Saved to DCIM/NativeCamera"
    }

    override fun onPreviewSize(width: Int, height: Int) {
        // The camera sends a landscape picture; held upright it is shown rotated, so the
        // on-screen height is screen width x (long side / short side).
        val screenW = resources.displayMetrics.widthPixels
        val h = (screenW.toFloat() * width / height).toInt()
        preview.layoutParams = FrameLayout.LayoutParams(screenW, h, Gravity.CENTER)
        grid.layoutParams = FrameLayout.LayoutParams(screenW, h, Gravity.CENTER)
    }

    override fun onStateChanged() {
        refresh()
        if (haveCameras) status.text = controller.summary()
    }

    override fun onRecording(recording: Boolean) {
        refresh()
        status.text = if (!recording) "Saved to DCIM/NativeCamera"
        else if (controller.paused) "Recording paused" else "Recording"
    }
}
