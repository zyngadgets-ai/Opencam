package com.nativecamera.app

import android.os.Build
import android.view.View
import android.view.WindowInsets

/** Keeps content clear of the status and navigation bars (Android draws edge to edge on new versions). */
@Suppress("DEPRECATION")
fun applySystemBarPadding(v: View) {
    v.setOnApplyWindowInsetsListener { view, insets ->
        if (Build.VERSION.SDK_INT >= 30) {
            val i = insets.getInsets(WindowInsets.Type.systemBars())
            view.setPadding(i.left, i.top, i.right, i.bottom)
        } else {
            view.setPadding(
                insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
                insets.systemWindowInsetRight, insets.systemWindowInsetBottom
            )
        }
        insets
    }
}
